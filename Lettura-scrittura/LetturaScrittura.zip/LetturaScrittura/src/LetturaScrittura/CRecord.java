package LetturaScrittura;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CRecord {

    // Dichiarazione delle varibili utilizzabili con CRecord.x
    public static int NCHIAMATA = 0;
    public static int DATA = 1;
    public static int ORA = 2; // CHANGES - Data divisa in "data" ed "ora"
    public static int TECNICO = 3;
    public static int CONTRATTO = 4;
    public static int COMMESSA = 5;
    public static int IMPIANTO = 6;
    public static int CODICE = 7;
    public static int CLIENTE = 8;
    public static int TELEFONO = 9;
    public static int EMAIL = 10;
    public static int CONTATTO = 11;
    public static int RIFERIMENTI = 12;
    public static int RICHIESTACLIENTE = 13;
    public static int PRESSO = 14;
    public static int TIPODIINTRVENTO = 15;
    public static int INDIRIZZOEMAIL = 16;
    public static int IDRIGA = 17;

    public static int numValori = 17;

    // Vettori utilizzati
    String[] nomiVariabili; // vetore dei nomi 
    String[] variabili; // vettore da modificare

    // Costruttore di default che inizializza i due vettori necessari
    public CRecord() {
        nomiVariabili = new String[]{
            "nChiamata",
            "Data",
            "Ora",
            "Tecnico",
            "Contratto",
            "Commessa",
            "Impianto",
            "Codice",
            "Cliente",
            "Telefono",
            "E-mail",
            "Contatto",
            "Riferimenti",
            "Richiesta Cliente",
            "Presso",
            "Tipo di intervento",
            "Indirizzo E-mail",
            "Idriga"
        };
        variabili = new String[numValori];
//        Date =  "";        
//        Hours =  ""; 
    }

    // Ritorna il valore della String in base all'indice dato 
    String getValoreInd(int pos) {
        if ((pos > 0) && (pos < numValori)) {
            return variabili[pos];
        }
        return null;
    }

    // Ritorna il valore della String in base alla posizione data 
    String getValorePos(int pos) {
        if ((pos > 0) && (pos < numValori)) {
            return variabili[pos - 1];
        }
        return null;
    }

    // Imposto valore in base alla posizione
    void setValore(String valore, int pos) {
        if ((pos > 0) && (pos < numValori)) {
            variabili[pos] = valore;
        }
    }

    // Prelevo i dati all'interno della stringa e li immetto nel vettore modificabile
    void parseString(String linea, String sep) {
        String[] str = linea.split(sep);
        for (int i = 0; i < numValori; i++) {
            if (i != DATA) {
                variabili[i] = str[i];
            } else {
                i++;
                variabili[i] = str[DATA].substring(12, 23);
                i--;
                variabili[i] = str[DATA].substring(0, 10);
                i++;
            }
        }
    }

    // Genero un tostring per visualizzare su una stringa le variabili
    public String toString(String finale) {
        String linea = "";
        for (int i = 0; i < numValori; i++) {
            linea += nomiVariabili[i] + ":" + variabili[i] + finale;
        }
        return linea;
    }

    // Genero una stringa da inserire nel file .csv 
    public String toCsvString(String finale) {
        String linea = "";
        for (int i = 0; i < numValori; i++) {
            linea += variabili[i] + finale;
        }
        linea += "\n";
        return linea;
    }

//    // Gestione della data
//    
//    // Dichiarazioni gestione data
//    String Date;
//    String Hours;
//    // Prendo la date e le ore e le immetto nelle variabili apposite
//    public void divideData() {
//        Date = getValorePos(DATA).substring(0, 10);
//        Hours = getValorePos(ORA).substring(12, 23);     
//    }
//    // Unisco alla varibile Data, le due variabili date e hour
//    public void unisciData() {
//        String temp = Date + "T" + Hours + "Z";
//        setValore(temp,DATA);       
//    }
}
