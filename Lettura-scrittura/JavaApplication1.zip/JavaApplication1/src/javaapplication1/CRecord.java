/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Vector;

/**
 *
 * @author rodrigues_alf
 */
public class CRecord {

        public static int NCHIAMATA= 0;
        public static int DATA = 1;
        public static int TECNICO = 2;
        public static int CONTRATTO = 3;
        public static int COMMESSA = 4;
        public static int IMPIANTO = 5;
        public static int CODICE = 6;
        public static int CLIENTE = 7;
        public static int TELEFONO = 8;
        public static int EMAIL= 9;
        public static int CONTATTO = 10;
        public static int RIFERIMENTI = 11;
        public static int RICHIESTACLIENTE= 12;
        public static int PRESSO = 13;
        public static int TIPODIINTRVENTO = 14;
        public static int INDIRIZZOEMAIL= 15;
        public static int IDRIGA = 16;
        
        public static int numValori;
        String[] nomiVariabili;
        String[] variabili;
        public CRecord()
        {
            numValori = 17;
            nomiVariabili = new String[]{
                "nChiamata",
                "Data",
                "Tecnico",
                "Contratto",
                "Commessa",
                "Impianto",
                "Codice",
                "Cliente",
                "Telefono",
                "E-mail",
                "Contatto",
                "Riferimenti",
                "Richiesta Cliente",
                "Presso",
                "Tipo di intervento",
                "Indirizzo E-mail",
                "Idriga"
            };
            variabili = new String[numValori];
        }
        
    

        String getValoreInd(int pos)
        {
            if ((pos > 0) && (pos < numValori))
            { return variabili[pos]; }
            return null;
        }
        
        String getValorePos(int pos)
        {
            if ((pos > 0) && (pos < numValori))
            { return variabili[pos-1]; }
            return null;
        }

        void setValore(String valore,int pos)
        {
            if ((pos > 0) && (pos < numValori))
            {
                variabili[pos] = valore;
            }
        }

        void parseString(String linea, String sep) {
            String []str = linea.split(sep);
            for (int i = 0; i < numValori; i++) {
               variabili[i] = str[i];
            }
        }

        public String toString(String finale) {
            String linea = "";
            for (int i = 0; i < numValori; i++) {
               linea += nomiVariabili[i] + ":" + variabili[i]+ finale;
            }
            return linea;
        }

    }