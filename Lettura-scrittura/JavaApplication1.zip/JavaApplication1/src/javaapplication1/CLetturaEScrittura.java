// Joao Alfredo Rodrigues Almeida 4°A - Inf
// Lettura da file .csv
package javaapplication1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CLetturaEScrittura {

    // parte lettura
    CRecord record;
    Vector vett;
    InputStreamReader flusso;
    String[] valori;
    int pos, numeroSplit;
    BufferedReader br;

    public CLetturaEScrittura() throws IOException {
        br = null;
        flusso = null;
        pos = 0;
        numeroSplit = CRecord.numValori;
        record = new CRecord();
        vett = new Vector();
        fout = null;

    }

    public void read(String nameFile, String Operatore) {

        try {
            br = new BufferedReader(new FileReader(nameFile));

            try {
                String line;

                line = br.readLine();
                while (line != null) {

                    record = new CRecord();
                    record.parseString(line, ";");
                    String s = record.getValoreInd(CRecord.TECNICO);
                    if (Operatore.compareTo(s) == 0) {
                        vett.add(record);
                    }
                    line = br.readLine();
                }
            } finally {
                br.close();
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CLetturaEScrittura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CLetturaEScrittura.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                br.close();
            } catch (IOException ex) {
                Logger.getLogger(CLetturaEScrittura.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public String toString() {
        String linea = "";
        for (int i = 0; i < vett.size(); i++) {
            CRecord cr = (CRecord) vett.get(i);
            linea += cr.toString("\n");
        }
        return linea;
    }

    // parte di scrittura
    BufferedWriter fout;

    void setNewFile(String fileName) throws IOException {
        boolean sentinel = true;
        fout = new BufferedWriter(new FileWriter(fileName, true));
        while (sentinel) {
            for (int i = 1; i < numeroSplit; i++) {
                fout.write(record.toCsvString(";"));
                fout.flush();
            }
            sentinel = false;
        }
    }
}
