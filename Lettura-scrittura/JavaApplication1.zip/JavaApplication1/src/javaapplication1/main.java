// Joao Alfredo Rodrigues Almeida 4°A - Inf
// Lettura e scrittura da file .csv
package javaapplication1;

import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;

public class main {

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        CLetturaEScrittura lett = new CLetturaEScrittura();
        lett.read("D:\\Temp\\elenco_interventi.csv", "XPIF");
        String str = lett.toString();
        Scanner sc = new Scanner(System.in);
        int i = -1;
        boolean sentinel = false;
        lett.setNewFile("D:\\Temp\\nuovoFile.csv");
        System.out.println(lett.toString());
//       do{ 
//        System.out.println("Quale riga vuoi leggere?");
//        i = sc.nextInt();
//        CRecord r = (CRecord)lett.vett.get(i-1);
//        System.out.println("Quale colonna vuoi leggere?");
//        i = sc.nextInt();
//        String s = r.getValore(i);
//        System.out.println(s);
//        System.out.println("Vuoi cobtinuare?");
//        sentinel = sc.nextBoolean();
//                
//       }while(sentinel);
    }

}
