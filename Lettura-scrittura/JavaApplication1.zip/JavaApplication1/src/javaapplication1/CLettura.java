/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rodrigues_alf
 */
public class CLettura {

    CRecord record;
    Vector vett;
    InputStreamReader flusso;
    String filename;
    String[] valori;
    int pos, numeroSplit;
    BufferedReader br;

    public CLettura() {
        br = null;
        pos = 0;
        numeroSplit = CRecord.numValori;
        record = new CRecord();
        vett = new Vector();

    }

    public void read(String nameFile, String Operatore) {

        try {
            br = new BufferedReader(new FileReader(nameFile));

            try {
                String line;

                line = br.readLine();

                while (line != null) {

                    record = new CRecord();
                    record.parseString(line, ";");
                    String s = record.getValoreInd(CRecord.TECNICO);
                    if (Operatore.compareTo(s)==0) {
                        vett.add(record);
                    }
                    line = br.readLine();
                }
            } finally {
                br.close();
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CLettura.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CLettura.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                br.close();
            } catch (IOException ex) {
                Logger.getLogger(CLettura.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public String toString() {
        String linea = "";
        for (int i = 0; i < vett.size(); i++) {
            CRecord cr = (CRecord) vett.get(i);
            linea += cr.toString("\n");
        }
        return linea;
    }
}
