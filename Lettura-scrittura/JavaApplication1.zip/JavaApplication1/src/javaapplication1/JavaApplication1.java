/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author rodrigues_alf
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CLettura lett = new CLettura();
        lett.read("D:\\Temp\\elenco_interventi.csv","XPIF");
        String str = lett.toString();
        Scanner sc = new Scanner(System.in);
        int i = -1;
        boolean sentinel = false;
        
        System.out.println(lett.toString());
//       do{ 
//        System.out.println("Quale riga vuoi leggere?");
//        i = sc.nextInt();
//        CRecord r = (CRecord)lett.vett.get(i-1);
//        System.out.println("Quale colonna vuoi leggere?");
//        i = sc.nextInt();
//        String s = r.getValore(i);
//        System.out.println(s);
//        System.out.println("Vuoi cobtinuare?");
//        sentinel = sc.nextBoolean();
//                
//       }while(sentinel);
    }
    
}
